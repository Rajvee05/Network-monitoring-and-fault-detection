# SOFI data placement

Download the processed CSVs for CoreSwitch-I and CoreSwitch-II from Mendeley Data version 2 and place both files directly in `data/raw/`. Keep the original file names where possible. Source metadata: 10.17632/tc6ysmh5j8.2, CC BY 4.0.

The provider's public description reports a binary `NE`/`F` label and approximately 12,971 instances across the SOFI benchmark; the training loader records the actual row count per file and combined after download. Time/timestamp and source identifiers are excluded from model features. No dataset is currently stored in this repository because the transfer could not complete in this environment.
