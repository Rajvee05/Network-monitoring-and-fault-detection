"""Explicit map limits between the live ping/TCP collector and SOFI SNMP model."""
SOFI_TO_LIVE_MAPPING={
 'ICMP_ping':'reachable (partial: live reachability can be ICMP or configured TCP)',
 'ICMP_response_time':'latency_ms (compatible only when the source is ICMP echo RTT)',
 'ICMP_loss':'packet_loss_pct (live value is rolling ICMP echo-miss rate)',
 'SNMP_availability':'not collected by current live collector',
 'P_/IN_/EX_ interface counters and status':'not collected; require authorized SNMP interface polling',
 'Device_uptime':'not collected',
 'IN/EX/P interface type and speed':'not collected',
}

def assert_compatible(live_measurement,feature_names):
 missing=[name for name in feature_names if name not in live_measurement]
 if missing:raise ValueError('Live collector cannot produce the full SOFI model feature vector; missing: '+', '.join(missing[:8])+('…' if len(missing)>8 else ''))
 return True
