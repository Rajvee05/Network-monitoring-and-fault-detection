"""ML pipeline components for the SOFI network fault benchmark."""
