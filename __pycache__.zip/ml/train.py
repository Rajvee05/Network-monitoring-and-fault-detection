"""Reproducible SOFI fault/anomaly experiment. No synthetic training fallback."""
from __future__ import annotations
import argparse, json
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import HistGradientBoostingClassifier, IsolationForest, RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.inspection import permutation_importance
from sklearn.metrics import (accuracy_score, average_precision_score, classification_report, confusion_matrix,
 f1_score, precision_recall_curve, precision_score, recall_score, roc_auc_score)
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from .data_preprocessing import DatasetError, load_sofi, make_splits

@dataclass
class Config:
 seed:int=42
 test_fraction:float=.20
 validation_fraction_of_trainval:float=.25
 time_block_hours:int=3
 iforest_normal_quantile:float=.01
 random_forest_trees:int=250
 hgb_iterations:int=160
 candidate_thresholds:int=91
 icmp_loss_rule_threshold:float=80.0

def preprocessing(X):
 numeric=list(X.select_dtypes(include=['number','bool']).columns)
 categorical=[c for c in X.columns if c not in numeric]
 transformers=[]
 if numeric:transformers.append(('numeric',Pipeline([('impute',SimpleImputer(strategy='median',add_indicator=True))]),numeric))
 if categorical:transformers.append(('categorical',Pipeline([('impute',SimpleImputer(strategy='most_frequent')),('onehot',OneHotEncoder(handle_unknown='ignore',sparse_output=False))]),categorical))
 if not transformers:raise DatasetError('No usable numeric or categorical features.')
 return ColumnTransformer(transformers,remainder='drop',verbose_feature_names_out=False)

def rule_predictions(X,icmp_loss_threshold=80.0):
 pred=np.zeros(len(X),dtype=int);evidence=[[] for _ in range(len(X))]
 columns={str(c).casefold():c for c in X.columns}
 for name,condition,reason in [
  ('icmp_ping',lambda s:pd.to_numeric(s,errors='coerce').fillna(1)<=0,'ICMP ping reports the device unreachable'),
  ('snmp_availability',lambda s:pd.to_numeric(s,errors='coerce').fillna(1)<=0,'SNMP availability reports the device unavailable'),
  ('icmp_loss',lambda s:pd.to_numeric(s,errors='coerce').fillna(0)>=icmp_loss_threshold,f'ICMP loss is at least {icmp_loss_threshold:g}%'),
 ]:
  if name in columns:
   mask=np.asarray(condition(X[columns[name]]),dtype=bool);pred[mask]=1
   for i in np.flatnonzero(mask):evidence[i].append(reason)
 return pred,evidence

def _classifier_candidates(X,y,cfg):
 return {
  'random_forest_leaf2':Pipeline([('preprocess',preprocessing(X)),('model',RandomForestClassifier(n_estimators=cfg.random_forest_trees,max_features='sqrt',min_samples_leaf=2,class_weight='balanced_subsample',random_state=cfg.seed,n_jobs=1))]),
  'random_forest_depth12_leaf4':Pipeline([('preprocess',preprocessing(X)),('model',RandomForestClassifier(n_estimators=cfg.random_forest_trees,max_features='sqrt',max_depth=12,min_samples_leaf=4,class_weight='balanced_subsample',random_state=cfg.seed,n_jobs=1))]),
  'hist_gradient_leaf15':Pipeline([('preprocess',preprocessing(X)),('model',HistGradientBoostingClassifier(max_iter=cfg.hgb_iterations,max_leaf_nodes=15,l2_regularization=1.0,class_weight='balanced',random_state=cfg.seed,early_stopping=True))]),
  'hist_gradient_leaf31':Pipeline([('preprocess',preprocessing(X)),('model',HistGradientBoostingClassifier(max_iter=cfg.hgb_iterations,max_leaf_nodes=31,l2_regularization=1.0,class_weight='balanced',random_state=cfg.seed,early_stopping=True))]),
 }

def _select_threshold(y,probs,count):
 candidates=np.unique(np.r_[np.linspace(.02,.98,count),probs])
 rows=[]
 for threshold in candidates:
  p=(probs>=threshold).astype(int);precision=precision_score(y,p,zero_division=0);recall=recall_score(y,p,zero_division=0);f1=f1_score(y,p,zero_division=0);tn,fp,fn,tp=confusion_matrix(y,p,labels=[0,1]).ravel();fpr=fp/max(1,fp+tn)
  rows.append((f1,precision,-fpr,threshold))
 return float(max(rows)[3])

def _metrics(y,p,score=None):
 y=np.asarray(y);p=np.asarray(p);tn,fp,fn,tp=confusion_matrix(y,p,labels=[0,1]).ravel()
 result={'accuracy':accuracy_score(y,p),'fault_precision':precision_score(y,p,zero_division=0),'fault_recall':recall_score(y,p,zero_division=0),'fault_f1':f1_score(y,p,zero_division=0),'macro_f1':f1_score(y,p,average='macro',zero_division=0),'weighted_f1':f1_score(y,p,average='weighted',zero_division=0),'false_positive_rate':fp/max(1,fp+tn),'false_negative_rate':fn/max(1,fn+tp),'confusion_matrix':[[int(tn),int(fp)],[int(fn),int(tp)]]}
 if score is not None and len(np.unique(y))==2:
  result['roc_auc']=roc_auc_score(y,score);result['pr_auc_average_precision']=average_precision_score(y,score)
 return result

def train_experiment(X,y,groups,diagnostics,config=None,output_dir=None,model_path=None):
 cfg=config or Config();X=X.reset_index(drop=True);y=np.asarray(y,dtype=int);groups=np.asarray(groups)
 tr,va,te,split_seed=make_splits(X,y,groups,cfg.seed,cfg.test_fraction,cfg.validation_fraction_of_trainval)
 Xtr,Xva,Xte=X.iloc[tr],X.iloc[va],X.iloc[te];ytr,yva,yte=y[tr],y[va],y[te]
 candidates=_classifier_candidates(Xtr,ytr,cfg);fitted={};thresholds={};val_scores={}
 for name,model in candidates.items():
  model.fit(Xtr,ytr);probs=model.predict_proba(Xva)[:,list(model.classes_).index(1)];threshold=_select_threshold(yva,probs,cfg.candidate_thresholds)
  fitted[name]=model;thresholds[name]=threshold;val_scores[name]=probs
 # Normal-only Isolation Forest: fit its encoder on training normal records only.
 normal=Xtr.iloc[np.flatnonzero(ytr==0)];if_prep=preprocessing(normal);normal_z=if_prep.fit_transform(normal);if_model=IsolationForest(n_estimators=300,contamination='auto',max_samples='auto',random_state=cfg.seed,n_jobs=1).fit(normal_z)
 normal_scores=-if_model.score_samples(normal_z);if_threshold=float(np.quantile(normal_scores,1-cfg.iforest_normal_quantile))
 val_z=if_prep.transform(Xva);val_anom=-if_model.score_samples(val_z);val_if=(val_anom>if_threshold).astype(int)
 # Pick an operating point for the best supervised candidate using validation only.
 best_clf=max(fitted,key=lambda n:(f1_score(yva,(val_scores[n]>=thresholds[n]).astype(int),zero_division=0),f1_score(yva,(val_scores[n]>=thresholds[n]).astype(int),average='macro',zero_division=0)))
 val_sup=(val_scores[best_clf]>=thresholds[best_clf]).astype(int);val_rules,_=rule_predictions(Xva,cfg.icmp_loss_rule_threshold)
 val_strategies={'supervised':val_sup,'isolation_forest':val_if,'rules':val_rules,'hybrid_union':((val_sup+val_if+val_rules)>0).astype(int)}
 val_metrics={k:_metrics(yva,v) for k,v in val_strategies.items()}
 selected=max(val_strategies,key=lambda k:(val_metrics[k]['fault_f1'],val_metrics[k]['macro_f1'],val_metrics[k]['fault_precision']))
 # Evaluate all candidates once on the untouched holdout.
 test_scores={n:m.predict_proba(Xte)[:,list(m.classes_).index(1)] for n,m in fitted.items()}
 test_anom=-if_model.score_samples(if_prep.transform(Xte));test_if=(test_anom>if_threshold).astype(int);test_rules,rule_evidence=rule_predictions(Xte,cfg.icmp_loss_rule_threshold)
 test_supervised=(test_scores[best_clf]>=thresholds[best_clf]).astype(int)
 test_strategies={'supervised':test_supervised,'isolation_forest':test_if,'rules':test_rules,'hybrid_union':((test_supervised+test_if+test_rules)>0).astype(int)}
 comparison={k:_metrics(yte,v,test_scores[best_clf] if k=='supervised' else (test_anom if k=='isolation_forest' else None)) for k,v in test_strategies.items()}
 classifier_test_results={name:_metrics(yte,(score>=thresholds[name]).astype(int),score) for name,score in test_scores.items()}
 classifier_validation_results={name:{**_metrics(yva,(val_scores[name]>=thresholds[name]).astype(int),val_scores[name]),'threshold':thresholds[name]} for name in fitted}
 selected_pred=test_strategies[selected];selected_report=classification_report(yte,selected_pred,labels=[0,1],target_names=['NE','F'],output_dict=True,zero_division=0)
 # Explainability: permutation importance on validation only; global association, not causation.
 perm=permutation_importance(fitted[best_clf],Xva,yva,n_repeats=5,random_state=cfg.seed,scoring='f1',n_jobs=1)
 importance=sorted([{'feature':f,'importance_mean':float(v),'importance_std':float(s)} for f,v,s in zip(X.columns,perm.importances_mean,perm.importances_std)],key=lambda r:r['importance_mean'],reverse=True)
 data_report=dict(diagnostics);data_report.update({'total_rows_after_deduplication':len(X),'split_method':'randomized non-overlapping 3-hour timestamp blocks','split_seed':split_seed,'partition_rows':{'train':len(tr),'validation':len(va),'test':len(te)},'partition_fault_counts':{'train':int(ytr.sum()),'validation':int(yva.sum()),'test':int(yte.sum())},'feature_order':list(X.columns),'excluded_features':['timestamp/time column','source/device identifiers']})
 report={'experiment':{'created_utc':datetime.now(timezone.utc).isoformat(),'config':asdict(cfg),'algorithm_selection_metric':'validation fault F1, ties by macro-F1 then precision','selected_classifier':best_clf,'selected_operating_strategy':selected,'classifier_thresholds_from_validation':thresholds,'icmp_loss_rule_threshold_pct':cfg.icmp_loss_rule_threshold,'hyperparameter_candidates':list(fitted),'isolation_forest_threshold':if_threshold,'isolation_forest_score_definition':'-decision_function; higher means more unusual','normal_only_training_rows':int(len(normal)),'target':'binary healthy (NE) versus faulty (F)','feature_importance_note':'Validation-set permutation importance is global association, not causal attribution.'},'dataset':data_report,'validation':val_metrics,'classifier_validation_comparison':classifier_validation_results,'classifier_test_comparison':classifier_test_results,'test_model_comparison':comparison,'selected_test_classification_report':selected_report,'top_validation_permutation_importance':importance[:20]}
 if output_dir:
  out=Path(output_dir);out.mkdir(parents=True,exist_ok=True);_write_reports(out,report,yte,test_strategies[selected],test_scores[best_clf],test_anom,importance[:20],Xte)
 if model_path:
  path=Path(model_path);path.parent.mkdir(parents=True,exist_ok=True)
  artifact={'artifact_version':'1.1.0','trained_utc':report['experiment']['created_utc'],'feature_names':list(X.columns),'numeric_features':list(X.select_dtypes(include=['number','bool']).columns),'categorical_features':[c for c in X.columns if c not in X.select_dtypes(include=['number','bool']).columns],'label_mapping':{'NE':0,'F':1},'selected_classifier_name':best_clf,'selected_strategy':selected,'classifier_threshold':thresholds[best_clf],'classifier':fitted[best_clf],'classifier_thresholds':thresholds,'isolation_preprocessor':if_prep,'isolation_forest':if_model,'isolation_threshold':if_threshold,'normal_quantile':cfg.iforest_normal_quantile,'rule_thresholds':{'icmp_loss_pct':cfg.icmp_loss_rule_threshold},'global_permutation_importance':importance,'dataset_source':'SOFI Mendeley Data v2, binary NE/F; see dataset/README.md'}
  joblib.dump(artifact,path)
 return report

def _write_reports(out,report,y,pred,probs,anom,importance,Xtest):
 (out/'evaluation.json').write_text(json.dumps(report,indent=2,default=float),encoding='utf-8')
 pd.DataFrame(report['classifier_test_comparison']).T.to_csv(out/'classifier_comparison.csv');pd.DataFrame(report['test_model_comparison']).T.to_csv(out/'strategy_comparison.csv')
 pd.DataFrame(report['selected_test_classification_report']).T.to_csv(out/'per_class_report.csv')
 pd.DataFrame(report['selected_test_classification_report']) if False else None
 pd.DataFrame(report['test_model_comparison']['supervised']['confusion_matrix'],index=['actual_NE','actual_F'],columns=['predicted_NE','predicted_F']).to_csv(out/'selected_strategy_confusion_matrix.csv')
 pd.DataFrame(importance).to_csv(out/'validation_permutation_importance.csv',index=False)
 pd.DataFrame({'actual':np.asarray(y),'selected_prediction':np.asarray(pred),'supervised_fault_score':np.asarray(probs),'isolation_anomaly_score':np.asarray(anom)}).to_csv(out/'heldout_test_predictions.csv',index=False)
 fig,ax=plt.subplots(figsize=(5,4));cm=report['selected_test_classification_report'];selected=report['experiment']['selected_operating_strategy'];# matrix from chosen strategy
 from sklearn.metrics import confusion_matrix
 matrix=confusion_matrix(y,pred,labels=[0,1]);im=ax.imshow(matrix,cmap='Blues');ax.set(xticks=[0,1],yticks=[0,1],xticklabels=['NE','F'],yticklabels=['NE','F'],xlabel='Predicted',ylabel='Actual',title=f'Holdout confusion matrix · {selected}')
 for (i,j),v in np.ndenumerate(matrix):ax.text(j,i,str(v),ha='center',va='center')
 fig.colorbar(im,ax=ax);fig.tight_layout();fig.savefig(out/'confusion_matrix.png',dpi=160);plt.close(fig)
 from sklearn.metrics import precision_recall_curve
 precision,recall,_=precision_recall_curve(y,probs);fig,ax=plt.subplots(figsize=(5,4));ax.plot(recall,precision,color='#1769aa');ax.set(xlabel='Recall (fault)',ylabel='Precision (fault)',title='Classifier precision–recall · held-out test');ax.grid(alpha=.25);fig.tight_layout();fig.savefig(out/'precision_recall_curve.png',dpi=160);plt.close(fig)
 fig,ax=plt.subplots(figsize=(6,4));ax.hist(np.asarray(anom)[np.asarray(y)==0],bins=30,alpha=.7,label='NE');ax.hist(np.asarray(anom)[np.asarray(y)==1],bins=30,alpha=.7,label='F');ax.set(xlabel='Isolation Forest anomaly score (higher = unusual)',ylabel='Test samples',title='Held-out anomaly score distribution');ax.legend();ax.grid(alpha=.2);fig.tight_layout();fig.savefig(out/'anomaly_scores.png',dpi=160);plt.close(fig)
 imp=importance[:15][::-1];fig,ax=plt.subplots(figsize=(7,5));ax.barh([r['feature'] for r in imp],[r['importance_mean'] for r in imp],xerr=[r['importance_std'] for r in imp],color='#39a8c8');ax.set(xlabel='Mean F1 decrease after permutation',title='Validation permutation importance');ax.grid(axis='x',alpha=.2);fig.tight_layout();fig.savefig(out/'feature_importance.png',dpi=160);plt.close(fig)

def main(argv=None):
 root=Path(__file__).resolve().parents[1];parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--data-dir',type=Path,default=root/'data'/'raw');parser.add_argument('--model',type=Path,default=root/'models'/'sofi_hybrid_fault_model_v1.joblib');parser.add_argument('--reports',type=Path,default=root/'reports'/'sofi_experiment');args=parser.parse_args(argv)
 try:
  X,y,meta,diag=load_sofi(args.data_dir);groups=meta['groups'];report=train_experiment(X,y,groups,diag,output_dir=args.reports,model_path=args.model)
 except DatasetError as e:parser.exit(2,f'Dataset is not ready: {e}\n')
 print(f"Selected classifier: {report['experiment']['selected_classifier']}; strategy: {report['experiment']['selected_operating_strategy']}")
 print(f"Untouched test metrics: {json.dumps(report['test_model_comparison'][report['experiment']['selected_operating_strategy']],indent=2)}")
 print(f"Saved artifact: {args.model}\nSaved reports: {args.reports}")
if __name__=='__main__':main()

