"""Dataset loading and preprocessing for the SOFI binary network-fault benchmark."""
from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd

class DatasetError(ValueError): pass

LABEL_NAMES={'ne':0,'normal':0,'healthy':0,'f':1,'faulty':1,'fault':1}
TIME_NAMES={'timestamp','time','timestamp_utc','datetime'}
META_NAMES={'source_device','source_file','device_name','device_location','device_description','system_object_id'}

def _normal_name(value): return str(value).strip().lstrip('\ufeff')

def load_sofi(data_dir, files=None):
    root=Path(data_dir)
    paths=[Path(p) for p in files] if files else sorted(p for p in root.rglob('*.csv') if p.is_file())
    paths=[p for p in paths if p.name.lower().endswith('.csv')]
    if not paths: raise DatasetError(f'No CSV files found in {root}. Place the two SOFI processed files (CoreSwitch-I.csv and CoreSwitch-II.csv) in data/raw/.')
    frames=[]
    for path in paths:
        try:
            frame=pd.read_csv(path,sep=None,engine='python')
        except Exception as exc: raise DatasetError(f'Could not read {path.name}: {exc}') from exc
        original_columns=[_normal_name(c) for c in frame.columns]
        canonical_columns=[c.casefold() for c in original_columns]
        if len(set(canonical_columns))!=len(canonical_columns): raise DatasetError(f'{path.name} has duplicate column names after case normalization.')
        frame.columns=canonical_columns
        lower={c:c for c in frame.columns}
        label=next((lower[n] for n in ('class','label','target') if n in lower),None)
        if label is None: raise DatasetError(f'{path.name} needs a class/label/target column; received columns: {frame.columns.tolist()}')
        frame=frame.rename(columns={label:'class'})
        time_col=next((lower[n] for n in TIME_NAMES if n in lower),None)
        if time_col and time_col!='timestamp':frame=frame.rename(columns={time_col:'timestamp'})
        raw=frame['class'].astype('string').str.strip().str.casefold()
        unknown=sorted(set(raw.dropna())-set(LABEL_NAMES))
        if unknown: raise DatasetError(f'{path.name} has labels outside the documented NE/F binary task: {unknown}')
        frame['class']=raw.map(LABEL_NAMES)
        frame['source_device']=path.stem
        frames.append(frame)
    base=set(frames[0].columns)
    for p,f in zip(paths[1:],frames[1:]):
        if set(f.columns)!=base:
            raise DatasetError(f'{p.name} schema differs from {paths[0].name}; refusing silent column alignment.')
        f=f[frames[0].columns]
    data=pd.concat(frames,ignore_index=True)
    data=data.dropna(subset=['class']).copy().reset_index(drop=True);data['class']=data['class'].astype(int)
    if data['class'].nunique()!=2: raise DatasetError('Both NE (normal) and F (fault) labels are required for a meaningful supervised evaluation.')
    target=data.pop('class')
    time_col='timestamp' if 'timestamp' in data else None
    excluded={c for c in data.columns if c.casefold() in TIME_NAMES|META_NAMES}
    excluded.add('source_device')
    feature_cols=[c for c in data.columns if c not in excluded]
    if not feature_cols: raise DatasetError('No measurement features remain after excluding timestamps and identifiers.')
    X=data[feature_cols].copy()
    for col in X.columns:
        numeric=pd.to_numeric(X[col],errors='coerce')
        if numeric.notna().mean()>=.95:
            X[col]=numeric.replace([-1,np.inf,-np.inf],np.nan)
        else:
            X[col]=X[col].astype('string').str.strip().replace({'':pd.NA,'-1':pd.NA})
    raw_rows=len(X)
    dedupe=pd.concat([data.reset_index(drop=True),target.reset_index(drop=True).rename('__label')],axis=1)
    duplicate_mask=dedupe.duplicated(keep='first')
    duplicates=int(duplicate_mask.sum())
    keep=~duplicate_mask
    X=X.loc[keep].reset_index(drop=True);target=target.loc[keep].reset_index(drop=True)
    data=data.loc[keep].reset_index(drop=True)
    if len(X)<100: raise DatasetError(f'Only {len(X)} usable unique rows remain; at least 100 are required.')
    if target.nunique()!=2:raise DatasetError('Both classes must remain after exact duplicate removal.')
    diagnostics={
      'dataset':'SOFI', 'files':[str(p) for p in paths], 'rows_raw':raw_rows,'rows_after_exact_deduplication':len(X),
      'exact_duplicate_rows_removed':duplicates,'feature_count':len(feature_cols),'features':feature_cols,
      'label_column':'class','label_mapping':{'NE':0,'F':1},'class_counts':{'NE':int((target==0).sum()),'F':int((target==1).sum())},
      'missing_values_by_feature':{c:int(X[c].isna().sum()) for c in feature_cols if X[c].isna().any()},
      'timestamp_column':time_col,'source_device_counts':data['source_device'].value_counts().to_dict(),
    }
    meta={'timestamps':data[time_col].copy() if time_col else None,'groups':_time_groups(data[time_col]) if time_col else data['source_device'].copy(),'source_device':data['source_device'].copy()}
    return X,target.astype(int),meta,diagnostics

def _time_groups(series):
    numeric=pd.to_numeric(series,errors='coerce')
    if numeric.notna().mean()>.95:
        values=numeric.to_numpy(dtype=float)
    else:
        parsed=pd.to_datetime(series,errors='coerce',utc=True)
        if parsed.notna().mean()<.95: raise DatasetError('Timestamp column is neither mostly numeric epoch time nor parseable date/time.')
        values=parsed.astype('int64').to_numpy()/1e9
    if np.any(~np.isfinite(values)):raise DatasetError('Timestamp contains non-finite values; clean the dataset before training.')
    # Keep measurements from the same three-hour network window in one split.
    return pd.Series(np.floor(values/10800).astype('int64'),name='time_block')

def make_splits(X,y,groups,seed=42,test_size=.20,validation_size=.25):
    """Deterministic train/validation/test split with no shared three-hour blocks."""
    from sklearn.model_selection import GroupShuffleSplit
    import numpy as np
    groups=np.asarray(groups)
    if len(np.unique(groups))<10:
        raise DatasetError('Need at least 10 distinct time blocks for a leakage-aware three-way split.')
    for rs in range(seed,seed+100):
        outer=GroupShuffleSplit(n_splits=1,test_size=test_size,random_state=rs)
        trainval_idx,test_idx=next(outer.split(X,y,groups))
        if len(set(np.asarray(y)[test_idx]))<2:continue
        inner=GroupShuffleSplit(n_splits=1,test_size=validation_size,random_state=rs+1000)
        local_groups=groups[trainval_idx]
        tr_local,val_local=next(inner.split(X.iloc[trainval_idx],np.asarray(y)[trainval_idx],local_groups))
        train_idx=trainval_idx[tr_local];val_idx=trainval_idx[val_local]
        if len(set(np.asarray(y)[train_idx]))==2 and len(set(np.asarray(y)[val_idx]))==2 and len(set(np.asarray(y)[test_idx]))==2:
            assert not (set(groups[train_idx])&set(groups[val_idx]))
            assert not (set(groups[train_idx])&set(groups[test_idx]))
            assert not (set(groups[val_idx])&set(groups[test_idx]))
            return train_idx,val_idx,test_idx,rs
    raise DatasetError('Unable to construct train/validation/test partitions containing both labels while keeping three-hour time blocks isolated. Inspect fault timestamps or provide more labeled fault events.')

