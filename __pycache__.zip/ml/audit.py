"""Execute the saved unified inference pipeline on its untouched SOFI test partition."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import (accuracy_score, average_precision_score, confusion_matrix,
    f1_score, precision_score, recall_score, roc_auc_score)
from .data_preprocessing import load_sofi, make_splits
from .predict import predict_network_fault


def audit(data_dir=None, model_path=None, predictions_path=None):
    root = Path(__file__).resolve().parents[1]
    data_dir = Path(data_dir) if data_dir else root / "data" / "raw"
    model_path = Path(model_path) if model_path else root / "models" / "sofi_hybrid_fault_model_v1.joblib"
    predictions_path = Path(predictions_path) if predictions_path else root / "reports" / "sofi_experiment" / "heldout_test_predictions.csv"
    artifact = joblib.load(model_path)
    X, y, meta, diagnostics = load_sofi(data_dir)
    _, _, test_idx, split_seed = make_splits(X, y, meta["groups"], seed=42, test_size=.20, validation_size=.25)
    Xtest = X.iloc[test_idx].reset_index(drop=True)
    actual = np.asarray(y.iloc[test_idx], dtype=int)
    results = [predict_network_fault(row, artifact=artifact) for row in Xtest.to_dict(orient="records")]
    predicted = np.asarray([r["predicted_condition"] == "fault" for r in results], dtype=int)
    scores = np.asarray([r["supervised_fault_score"] for r in results], dtype=float)
    anomaly = np.asarray([r["components"]["isolation_forest"]["flag"] for r in results], dtype=bool)
    rules = np.asarray([r["components"]["diagnostic_rules"]["flag"] for r in results], dtype=bool)
    if not all(r.get("status") == "ok" for r in results):
        raise RuntimeError("At least one held-out record was not accepted by unified inference.")
    cm = confusion_matrix(actual, predicted, labels=[0, 1])
    metrics = {
        "records": int(len(actual)),
        "fault_records": int(actual.sum()),
        "accuracy": float(accuracy_score(actual, predicted)),
        "fault_precision": float(precision_score(actual, predicted, zero_division=0)),
        "fault_recall": float(recall_score(actual, predicted, zero_division=0)),
        "fault_f1": float(f1_score(actual, predicted, zero_division=0)),
        "macro_f1": float(f1_score(actual, predicted, average="macro", zero_division=0)),
        "false_positive_rate": float(cm[0, 1] / max(1, cm[0].sum())),
        "false_negative_rate": float(cm[1, 0] / max(1, cm[1].sum())),
        "confusion_matrix_actual_rows_predicted_columns": cm.tolist(),
        "supervised_roc_auc": float(roc_auc_score(actual, scores)),
        "supervised_pr_auc_average_precision": float(average_precision_score(actual, scores)),
        "isolation_forest_flagged_records": int(anomaly.sum()),
        "diagnostic_rules_flagged_records": int(rules.sum()),
    }
    parity = None
    if predictions_path.is_file():
        expected = pd.read_csv(predictions_path)
        parity = {
            "report_rows_match": len(expected) == len(actual) and np.array_equal(expected["actual"].to_numpy(dtype=int), actual),
            "selected_predictions_match_saved_training_report": len(expected) == len(actual) and np.array_equal(expected["selected_prediction"].to_numpy(dtype=int), predicted),
            "supervised_scores_match_saved_training_report": len(expected) == len(actual) and bool(np.allclose(expected["supervised_fault_score"].to_numpy(dtype=float), scores, rtol=1e-10, atol=1e-12)),
        }
        if not all(parity.values()):
            raise RuntimeError(f"Unified inference disagrees with the saved held-out training report: {parity}")
    normal_ix = next(i for i, label in enumerate(actual) if label == 0)
    fault_ix = next(i for i, label in enumerate(actual) if label == 1)
    anomaly_ix = int(np.argmax([r["anomaly_score"] for r in results]))
    summary = {
        "dataset": "SOFI actual untouched test partition",
        "split_seed": int(split_seed),
        "selected_classifier": artifact.get("selected_classifier_name"),
        "selected_strategy": artifact.get("selected_strategy"),
        "feature_count": len(artifact["feature_names"]),
        "feature_order_validated": all(r["feature_order_used"] == artifact["feature_names"] for r in results),
        "metrics": metrics,
        "saved_report_parity": parity,
        "sample_checks": {
            "normal_record": {"actual": "normal", "prediction": results[normal_ix]["predicted_condition"], "fault_score": results[normal_ix]["supervised_fault_score"], "anomaly_flag": results[normal_ix]["components"]["isolation_forest"]["flag"]},
            "known_fault_record": {"actual": "fault", "prediction": results[fault_ix]["predicted_condition"], "fault_score": results[fault_ix]["supervised_fault_score"], "diagnostic_rule_evidence": results[fault_ix]["components"]["diagnostic_rules"]["evidence"]},
            "highest_anomaly_score_record": {"actual": "fault" if actual[anomaly_ix] else "normal", "prediction": results[anomaly_ix]["predicted_condition"], "anomaly_score": results[anomaly_ix]["anomaly_score"], "anomaly_threshold": results[anomaly_ix]["anomaly_threshold"], "anomaly_flag": results[anomaly_ix]["components"]["isolation_forest"]["flag"]},
        },
        "dataset_diagnostics": {"total_rows": diagnostics["rows_after_exact_deduplication"], "fault_rows": diagnostics["class_counts"]["F"], "normal_rows": diagnostics["class_counts"]["NE"]},
    }
    return summary


def main():
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, default=root / "data" / "raw")
    parser.add_argument("--model", type=Path, default=root / "models" / "sofi_hybrid_fault_model_v1.joblib")
    parser.add_argument("--predictions", type=Path, default=root / "reports" / "sofi_experiment" / "heldout_test_predictions.csv")
    parser.add_argument("--output", type=Path, default=root / "reports" / "sofi_experiment" / "unified_inference_audit.json")
    args = parser.parse_args()
    result = audit(args.data_dir, args.model, args.predictions)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))
    print(f"Saved audit: {args.output}")

if __name__ == "__main__":
    main()
