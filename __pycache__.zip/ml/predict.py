"""Unified inference for the saved SOFI network fault model."""
from __future__ import annotations
from collections.abc import Mapping
from pathlib import Path
from functools import lru_cache
import math
import numbers
import joblib
import numpy as np
import pandas as pd

class InferenceInputError(ValueError):
    """Raised when an inference row is incompatible with the trained schema."""

LIVE_FIELDS = {
    # Collector.check() output. These names deliberately do not alias SOFI fields.
    "reachable", "method", "latency_ms", "service_ok", "packet_loss_pct",
    "cpu_pct", "memory_pct", "tx_bytes_sec", "rx_bytes_sec", "error",
    "ping_ok", "fail_streak", "good_streak",
}
METADATA_FIELDS = {"class", "label", "target", "timestamp", "time", "timestamp_utc", "datetime", "source_device", "source_file", "device_name", "device_location", "device_description", "system_object_id"}


@lru_cache(maxsize=4)
def _load_artifact(artifact_path=None):
    if artifact_path is None:
        artifact_path = Path(__file__).resolve().parents[1] / "models" / "sofi_hybrid_fault_model_v1.joblib"
    path = Path(artifact_path)
    if not path.is_file():
        raise FileNotFoundError(f"Model artifact not found at {path}. Run python -m ml.train first.")
    return joblib.load(path)


def _validated_row(record, artifact):
    if not isinstance(record, Mapping):
        raise InferenceInputError("Provide one SOFI measurement row as a mapping of feature name to value.")
    names = artifact.get("feature_names")
    if not isinstance(names, list) or not names:
        raise InferenceInputError("The saved model does not contain a valid feature order.")
    normalized = {}
    for key, value in record.items():
        if not isinstance(key, str):
            raise InferenceInputError("Every feature name must be text.")
        canonical = key.strip().casefold()
        if not canonical:
            raise InferenceInputError("Feature names cannot be blank.")
        if canonical in normalized:
            raise InferenceInputError(f"Duplicate feature name after case normalization: {key!r}.")
        normalized[canonical] = value
    names_by_case = {name.casefold(): name for name in names}
    missing = [name for name in names if name.casefold() not in normalized]
    if missing:
        if set(normalized).issubset(LIVE_FIELDS | METADATA_FIELDS):
            raise InferenceInputError("Live ping/TCP measurements do not match the SOFI model. It requires the complete SOFI SNMP/interface feature schema; unsupported live prediction was blocked.")
        raise InferenceInputError(f"Missing required SOFI feature(s): {missing}")
    extras = sorted(key for key in normalized if key not in names_by_case and key not in METADATA_FIELDS)
    if extras:
        raise InferenceInputError(f"Unexpected feature(s): {extras}")
    numeric = set(artifact.get("numeric_features", []))
    categorical = set(artifact.get("categorical_features", []))
    row_values = {}
    for feature in names:
        value = normalized[feature.casefold()]
        if value is None or value is pd.NA:
            row_values[feature] = np.nan
            continue
        if isinstance(value, (list, tuple, dict, set, np.ndarray)):
            raise InferenceInputError(f"Feature {feature!r} must be a scalar value or missing, not {type(value).__name__}.")
        try:
            missing_value = pd.isna(value)
            if isinstance(missing_value, (bool, np.bool_)) and missing_value:
                row_values[feature] = np.nan
                continue
        except (TypeError, ValueError):
            pass
        if feature in numeric:
            if isinstance(value, bool):
                number = float(value)
            elif isinstance(value, numbers.Real):
                number = float(value)
            else:
                try:
                    number = float(str(value).strip())
                except (TypeError, ValueError):
                    raise InferenceInputError(f"Numeric feature {feature!r} must be a finite number or missing.") from None
            if not math.isfinite(number):
                raise InferenceInputError(f"Numeric feature {feature!r} must be finite; use None for a missing value.")
            row_values[feature] = number
        elif feature in categorical:
            if not isinstance(value, (str, numbers.Number, bool, np.generic)):
                raise InferenceInputError(f"Categorical feature {feature!r} must be text, a number, or missing.")
            row_values[feature] = str(value).strip() if isinstance(value, str) else value
        else:
            # Backward-compatible artifact fallback; preprocessing still enforces the fitted schema.
            row_values[feature] = value
    return pd.DataFrame([{name: row_values[name] for name in names}], columns=names), row_values


def predict_network_fault(features, artifact_path=None, artifact=None):
    """Run classifier, Isolation Forest, measured rules, and diagnosis as one prediction.

    Input must contain every trained SOFI feature. Missing values are permitted and
    handled by the saved training imputers. Live collector records are rejected.
    """
    artifact = artifact if artifact is not None else _load_artifact(artifact_path)
    row, normalized = _validated_row(features, artifact)
    required = ("classifier", "isolation_preprocessor", "isolation_forest", "feature_names", "classifier_threshold", "isolation_threshold", "selected_strategy")
    absent = [name for name in required if name not in artifact]
    if absent:
        raise InferenceInputError(f"Saved model artifact is incomplete: {absent}")
    classifier = artifact["classifier"]
    classes = list(classifier.classes_)
    if 1 not in classes:
        raise InferenceInputError("Saved classifier has no positive fault class (label 1).")
    positive_index = classes.index(1)
    supervised_score = float(classifier.predict_proba(row)[0, positive_index])
    supervised_threshold = float(artifact["classifier_threshold"])
    supervised_fault = supervised_score >= supervised_threshold

    encoded = artifact["isolation_preprocessor"].transform(row)
    anomaly_score = float(-artifact["isolation_forest"].score_samples(encoded)[0])
    anomaly_threshold = float(artifact["isolation_threshold"])
    anomalous = anomaly_score > anomaly_threshold

    from .train import rule_predictions
    rule_pred, evidence = rule_predictions(row, artifact.get("rule_thresholds", {}).get("icmp_loss_pct", 80.0))
    rule_fault = bool(rule_pred[0])
    strategy = artifact["selected_strategy"]
    strategy_decisions = {
        "supervised": supervised_fault,
        "isolation_forest": anomalous,
        "rules": rule_fault,
        "hybrid_union": supervised_fault or anomalous or rule_fault,
    }
    if strategy not in strategy_decisions:
        raise InferenceInputError(f"Unsupported saved decision strategy: {strategy!r}")
    selected = strategy_decisions[strategy]
    secondary_signals = []
    if anomalous and strategy in {'supervised', 'rules'}:
        secondary_signals.append('Isolation Forest flags this row as unusual; it does not change the validation-selected fault decision policy.')
    if rule_fault and strategy in {'supervised', 'isolation_forest'}:
        secondary_signals.extend(evidence[0])
    if not selected:
        severity = "info"
        diagnosis = "No fault detected by the selected operating policy." + (" Additional review signal: " + "; ".join(secondary_signals) if secondary_signals else "")
        steps = []
    elif evidence[0]:
        severity = "critical" if any("unreachable" in e.lower() or "unavailable" in e.lower() for e in evidence[0]) else "high"
        diagnosis = "Measured availability symptom: " + "; ".join(evidence[0])
        steps = ["Check reachability, link state, and interface status.", "Correlate with service checks and recent network changes."]
    elif anomalous and strategy == "isolation_forest":
        severity = "medium"
        diagnosis = "The measurement is outside the learned normal-only baseline; this is an anomaly flag, not a confirmed fault cause."
        steps = ["Inspect interface errors, drops, status, and traffic rates.", "Compare with adjacent time windows and a second measurement source."]
    else:
        severity = "medium"
        diagnosis = "The observed feature pattern resembles labeled SOFI fault records; this is a symptom classification, not confirmed root cause."
        steps = ["Inspect interface errors, drops, operational status, and traffic rates.", "Correlate with device logs before assigning a root cause."]
    importance = artifact.get("global_permutation_importance", [])[:5]
    context = [{"feature": item["feature"], "value": normalized.get(item["feature"].casefold()), "global_importance_mean": item["importance_mean"]} for item in importance]
    return {
        "status": "ok",
        "predicted_condition": "fault" if selected else "normal",
        "severity": severity,
        "selected_strategy": strategy,
        "diagnosis": diagnosis,
        "decision_basis": {"policy": strategy, "selected_policy_flag": bool(selected), "secondary_signals": secondary_signals},
        "components": {
            "supervised_classifier": {"fault_score": supervised_score, "threshold": supervised_threshold, "flag": bool(supervised_fault)},
            "isolation_forest": {"anomaly_score": anomaly_score, "threshold": anomaly_threshold, "flag": bool(anomalous)},
            "diagnostic_rules": {"flag": rule_fault, "evidence": evidence[0]},
        },
        "supervised_fault_score": supervised_score,
        "supervised_threshold": supervised_threshold,
        "anomaly_score": anomaly_score,
        "anomaly_threshold": anomaly_threshold,
        "rule_evidence": evidence[0],
        "normal_or_anomalous": "anomalous" if anomalous else "within_baseline",
        "suggested_troubleshooting": steps,
        "important_features_context": context,
        "feature_order_used": list(artifact["feature_names"]),
        "explanation_limit": "Classifier scores are not calibrated probabilities. SOFI labels are binary NE/F; exact fault type is unavailable. Permutation importance is global association, not causal attribution.",
    }


def predict_record(record, artifact_path=None, artifact=None):
    """Backward-compatible name for the unified prediction interface."""
    return predict_network_fault(record, artifact_path=artifact_path, artifact=artifact)


def predict_live_measurement(measurement, artifact_path=None, artifact=None, provenance=None):
    """Infer only from a complete SOFI-compatible row; otherwise explain the gap.

    Collector telemetry is not translated into SOFI feature names. Rolling echo loss
    is not the SOFI ICMP polling loss, and host byte rates are not per-interface
    P/IN/EX SNMP counters.
    """
    if not isinstance(measurement, Mapping):
        return {"status": "not_supported", "reason": "Live measurement must be a mapping.",
                "model_dataset": "SOFI processed SNMP/interface feature schema", "model_executed": False}
    try:
        model_artifact = artifact if artifact is not None else _load_artifact(artifact_path)
    except (FileNotFoundError, OSError) as exc:
        return {"status": "not_supported", "reason": str(exc),
                "model_dataset": "SOFI processed SNMP/interface feature schema", "model_executed": False}
    names = list(model_artifact.get("feature_names", []))
    normalized_keys = {str(k).strip().casefold() for k in measurement if isinstance(k, str)}
    expected = {name.casefold() for name in names}
    if expected.issubset(normalized_keys) and provenance == "verified_sofi_compatible_live_snmp":
        try:
            result = predict_network_fault(measurement, artifact=model_artifact)
            result["model_executed"] = True
            result["input_provenance"] = "SOFI-compatible feature row supplied by caller; live source provenance must be verified by caller"
            return result
        except InferenceInputError as exc:
            return {"status": "invalid_input", "reason": str(exc), "model_executed": False,
                    "model_dataset": "SOFI processed SNMP/interface feature schema"}
    provided_sofi = [name for name in names if name.casefold() in normalized_keys]
    if expected.issubset(normalized_keys) and provenance != "verified_sofi_compatible_live_snmp":
        return {
            "status": "not_supported",
            "reason": "All feature names are present, but live inference requires explicit verified provenance that the row uses the same SOFI polling groups, units, aggregation windows, and interface semantics. No model inference was executed.",
            "model_dataset": "SOFI processed SNMP/interface feature schema",
            "model_executed": False,
            "provided_sofi_feature_names": provided_sofi,
            "missing_required_features": [],
        }
    missing = [name for name in names if name.casefold() not in normalized_keys]
    details = (
        "NetSentinel's verified live collector currently supplies reachability, ICMP echo/TCP-connect timing, "
        "rolling 20-check echo loss, service status, local host CPU/memory, and aggregate host interface byte rates. "
        "These measurements do not constitute the trained SOFI model input row: it requires the SOFI polling-group 'range', "
        "P/IN/EX-specific SNMP packet discard/error counters, bit counters, interface speeds/types and operational "
        "statuses, device uptime, SNMP availability, plus SOFI-compatible ICMP fields. The collector's latency can "
        "be TCP fallback and its rolling loss window/host byte rates have different provenance and semantics. "
        "No missing feature is synthesized or mapped, and no Random Forest inference was executed."
    )
    return {
        "status": "not_supported", "reason": details,
        "model_dataset": "SOFI processed SNMP/interface feature schema",
        "model_executed": False,
        "provided_sofi_feature_names": provided_sofi,
        "missing_required_features": missing,
        "unmapped_live_measurements": sorted(str(k) for k in measurement if isinstance(k, str) and k.casefold() in LIVE_FIELDS),
    }