"""Integration checks against the supplied SOFI data and trained model artifact."""
import unittest
import importlib.util
from pathlib import Path
import joblib
import numpy as np
from ml.data_preprocessing import load_sofi, make_splits
from ml.predict import InferenceInputError, predict_network_fault, predict_live_measurement
import netsentinel_simulation as SIMULATION
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "raw"
MODEL = ROOT / "models" / "sofi_hybrid_fault_model_v1.joblib"
REPLAY_SPEC = importlib.util.spec_from_file_location("sofi_replay_app", ROOT / "SOFI-Replay.py")
REPLAY_APP = importlib.util.module_from_spec(REPLAY_SPEC)
REPLAY_SPEC.loader.exec_module(REPLAY_APP)

@unittest.skipUnless(MODEL.is_file() and DATA.is_dir() and list(DATA.glob("*.csv")), "requires downloaded SOFI CSVs and trained artifact")
class RealSOFIIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.artifact = joblib.load(MODEL)
        X, y, meta, _ = load_sofi(DATA)
        _, _, test_idx, _ = make_splits(X, y, meta["groups"], seed=42, test_size=.20, validation_size=.25)
        cls.Xtest = X.iloc[test_idx].reset_index(drop=True)
        cls.ytest = np.asarray(y.iloc[test_idx], dtype=int)

    def test_saved_model_schema_preprocessing_and_labels(self):
        self.assertEqual(len(self.artifact["feature_names"]), 33)
        self.assertEqual(self.artifact["label_mapping"], {"NE": 0, "F": 1})
        self.assertEqual(self.artifact["selected_classifier_name"], "random_forest_leaf2")
        self.assertEqual(type(self.artifact["classifier"]).__name__, "Pipeline")
        self.assertEqual(set(self.artifact["classifier"].named_steps), {"preprocess", "model"})
        self.assertEqual(type(self.artifact["classifier"].named_steps["model"]).__name__, "RandomForestClassifier")
        self.assertEqual(len(self.artifact["numeric_features"]), 33)
        self.assertEqual(self.artifact["categorical_features"], [])
        self.assertEqual(type(self.artifact["isolation_preprocessor"]).__name__, "ColumnTransformer")

    def test_real_normal_fault_and_anomaly_inputs(self):
        normal_ix = int(np.flatnonzero(self.ytest == 0)[0])
        normal_result = predict_network_fault(self.Xtest.iloc[normal_ix].to_dict(), artifact=self.artifact)
        self.assertEqual(normal_result["status"], "ok")
        self.assertEqual(normal_result["components"]["supervised_classifier"]["flag"], False)

        probs = self.artifact["classifier"].predict_proba(self.Xtest)[:, list(self.artifact["classifier"].classes_).index(1)]
        tp_ixs = np.flatnonzero((self.ytest == 1) & (probs >= self.artifact["classifier_threshold"]))
        self.assertGreater(len(tp_ixs), 0, "held-out set should contain a detected known-fault sample")
        fault_result = predict_network_fault(self.Xtest.iloc[int(tp_ixs[0])].to_dict(), artifact=self.artifact)
        self.assertEqual(fault_result["predicted_condition"], "fault")
        self.assertIn("diagnostic_rules", fault_result["components"])

        encoded = self.artifact["isolation_preprocessor"].transform(self.Xtest)
        anomaly_scores = -self.artifact["isolation_forest"].score_samples(encoded)
        anomaly_ix = int(np.argmax(anomaly_scores))
        anomaly_result = predict_network_fault(self.Xtest.iloc[anomaly_ix].to_dict(), artifact=self.artifact)
        self.assertTrue(anomaly_result["components"]["isolation_forest"]["flag"])
        self.assertEqual(anomaly_result["feature_order_used"], self.artifact["feature_names"])

    def test_faculty_demo_cases_run_through_saved_model(self):
        probs = self.artifact["classifier"].predict_proba(self.Xtest)[:, list(self.artifact["classifier"].classes_).index(1)]
        expected = (probs >= float(self.artifact["classifier_threshold"])).astype(int)
        normal_ix, fault_ix = REPLAY_APP.select_faculty_examples(self.ytest, expected)
        normal_actual, normal_result = REPLAY_APP.infer_demo_case(self.Xtest, self.ytest, normal_ix, self.artifact, expected[normal_ix])
        fault_actual, fault_result = REPLAY_APP.infer_demo_case(self.Xtest, self.ytest, fault_ix, self.artifact, expected[fault_ix])
        self.assertEqual(normal_actual, 0)
        self.assertEqual(normal_result["predicted_condition"], "normal")
        self.assertEqual(fault_actual, 1)
        self.assertEqual(fault_result["predicted_condition"], "fault")
        self.assertAlmostEqual(fault_result["supervised_fault_score"], float(probs[fault_ix]), places=12)
        self.assertAlmostEqual(fault_result["supervised_threshold"], float(self.artifact["classifier_threshold"]), places=12)
    def test_illustrative_topology_does_not_claim_sofi_fault_mapping(self):
        self.assertEqual({item["name"] for item in REPLAY_APP.TOPOLOGY_DEVICES.values()}, {"PC1", "PC2", "Switch S1", "Router R1", "Server1"})
        self.assertEqual(len(REPLAY_APP.TOPOLOGY_LINKS), 4)
        self.assertFalse(REPLAY_APP.PACKET_TRACER_INTEGRATED)
        heldout_fault = {"source": "SOFI CoreSwitch-I", "row": 983, "actual": "F (fault)", "predicted": "F (fault)", "score": 40.65, "threshold": 38.84}
        device = REPLAY_APP.build_topology_device_inspection("r1", heldout_fault)
        link = REPLAY_APP.build_topology_link_inspection("s1_r1", heldout_fault)
        self.assertIn("Not measured", device["monitoring_status"])
        self.assertIn("No fault is attributed", device["fault_attribution"])
        self.assertIn("no endpoint-level topology mapping", link["fault_attribution"])
        self.assertEqual(device["heldout_result"]["actual"], "F (fault)")
        self.assertIn("not probed", link["status"])
    def test_real_schema_rejects_invalid_and_live_inputs(self):
        record = self.Xtest.iloc[0].to_dict()
        missing = dict(record); missing.pop(self.artifact["feature_names"][0])
        with self.assertRaises(InferenceInputError):
            predict_network_fault(missing, artifact=self.artifact)
        bad = dict(record); bad[self.artifact["feature_names"][0]] = float("inf")
        with self.assertRaises(InferenceInputError):
            predict_network_fault(bad, artifact=self.artifact)
        live = predict_live_measurement({"reachable": True, "latency_ms": 4.2, "service_ok": True}, artifact_path=MODEL)
        self.assertEqual(live["status"], "not_supported")
        self.assertIn("SOFI model", live["reason"])
        self.assertFalse(live["model_executed"])
        self.assertEqual(len(live["missing_required_features"]), 33)

    def test_live_gate_executes_only_complete_compatible_feature_rows(self):
        row = self.Xtest.iloc[0].to_dict()
        accepted = predict_live_measurement(row, artifact=self.artifact, provenance="verified_sofi_compatible_live_snmp")
        self.assertEqual(accepted["status"], "ok")
        self.assertTrue(accepted["model_executed"])
        from ml import predict as inference
        with patch.object(inference, "predict_network_fault", side_effect=AssertionError("incompatible collector data reached RF")):
            rejected = predict_live_measurement({
                "reachable": True, "method": "TCP connect time", "latency_ms": 4.2,
                "packet_loss_pct": 0.0, "cpu_pct": 12.0, "memory_pct": 42.0,
                "tx_bytes_sec": 10.0, "rx_bytes_sec": 20.0, "service_ok": True,
                "ping_ok": False, "fail_streak": 0, "good_streak": 1, "error": None,
            }, artifact=self.artifact)
        self.assertEqual(rejected["status"], "not_supported")
        self.assertFalse(rejected["model_executed"])
        self.assertTrue(rejected["missing_required_features"])
        self.assertIn("TCP fallback", rejected["reason"])
        unverified = predict_live_measurement(row, artifact=self.artifact)
        self.assertEqual(unverified["status"], "not_supported")
        self.assertFalse(unverified["model_executed"])
        self.assertIn("provenance", unverified["reason"])

class TopologySimulationTests(unittest.TestCase):
    def test_normal_fault_detection_recovery_is_ordered_and_rule_consistent(self):
        sim = REPLAY_APP.TopologySimulation()
        sim.start("2026-10-25T10:00:00+05:30")
        self.assertEqual(sim.last_diagnosis["condition"], "normal")
        self.assertEqual((sim.last_measurement["probes_ok"], sim.last_measurement["probes_failed"]), (4, 0))
        start_event_count = len(sim.events)
        sim.inject("link_down", "2026-10-25T10:00:01+05:30")
        _, diagnosis = sim.check("2026-10-25T10:00:02+05:30")
        self.assertEqual(diagnosis["condition"], "fault")
        self.assertEqual(sim.last_measurement["probes_failed"], 4)
        self.assertIn("link unavailable", diagnosis["rule"])
        self.assertFalse(sim.recovery_pending)
        sim.clear_fault("2026-10-25T10:00:03+05:30")
        self.assertFalse(sim.recovery_pending)
        self.assertEqual(sim.last_diagnosis["condition"], "normal")
        self.assertEqual(sim.last_measurement["probes_ok"], 4)
        kinds = [event["event"] for event in sim.events]
        fault_at = kinds.index("Simulated fault injected", start_event_count)
        measurement_at = kinds.index("Monitoring measurement collected", fault_at)
        pipeline_at = kinds.index("Detection pipeline executed", measurement_at)
        result_at = kinds.index("Fault result reported", pipeline_at)
        recovery_at = kinds.index("Recovery detected", result_at)
        self.assertLess(fault_at, measurement_at)
        self.assertLess(measurement_at, pipeline_at)
        self.assertLess(pipeline_at, result_at)
        self.assertLess(result_at, recovery_at)
        self.assertTrue(all(event["wall_time"].startswith("2026-10-25") for event in sim.events))
        self.assertTrue(all(event["simulation_time"].startswith("T+") for event in sim.events))
        self.assertIn("Random Forest skipped", sim.events[pipeline_at]["detail"])

    def test_each_scenario_uses_rules_and_never_sends_topology_features_to_sofi(self):
        expected = {"normal": "normal", "link_down": "fault", "server_unreachable": "fault", "degraded": "degraded"}
        for scenario, condition in expected.items():
            with self.subTest(scenario=scenario):
                sim = REPLAY_APP.TopologySimulation()
                sim.start("2026-10-25T10:00:00+05:30")
                sim.inject(scenario, "2026-10-25T10:00:01+05:30")
                _, result = sim.check("2026-10-25T10:00:02+05:30")
                self.assertEqual(result["condition"], condition)
                self.assertEqual(sim.last_measurement["source"], "simulated topology")
                self.assertIn("SOFI compatibility gate", sim.events[-2]["detail"])
                self.assertFalse(sim.last_model_assessment["model_executed"])
                self.assertEqual(sim.last_model_assessment["status"], "not_supported")

    @classmethod
    def setUpClass(cls):
        cls.artifact = joblib.load(MODEL)
        X, y, meta, _ = load_sofi(DATA)
        _, _, test_idx, _ = make_splits(X, y, meta["groups"], seed=42, test_size=.20, validation_size=.25)
        cls.Xtest = X.iloc[test_idx].reset_index(drop=True)
        cls.ytest = np.asarray(y.iloc[test_idx], dtype=int)

    def test_simulated_observation_is_blocked_before_random_forest_call(self):
        sim = REPLAY_APP.TopologySimulation(model_artifact=self.artifact)
        with patch.object(SIMULATION, "predict_network_fault") as model_call:
            sim.start("2026-10-25T10:00:00+05:30")
            sim.inject("link_down", "2026-10-25T10:00:01+05:30")
            model_call.assert_not_called()
        self.assertFalse(sim.last_model_assessment["model_executed"])
        self.assertEqual(sim.last_model_assessment["status"], "not_supported")
        self.assertIn("not SOFI ICMP/SNMP measurements", sim.last_model_assessment["reason"])
        self.assertEqual(sim.last_diagnosis["condition"], "fault")
        self.assertNotIn("predicted_condition", sim.last_model_assessment)
        pipeline_event = next(event for event in reversed(sim.events) if event["event"] == "Detection pipeline executed")
        self.assertIn("Random Forest skipped", pipeline_event["detail"])
        result_event = next(event for event in reversed(sim.events) if event["event"] == "Fault result reported")
        self.assertIn("FAULT", result_event["detail"])

    def test_explicit_recorded_sofi_vector_reaches_saved_model_but_invalid_vector_does_not(self):
        normal_ix = int(np.flatnonzero(self.ytest == 0)[0])
        features = self.Xtest.iloc[normal_ix].to_dict()
        result = SIMULATION.infer_sofi_observation({"source": "recorded_sofi", "sofi_features": features}, artifact=self.artifact)
        self.assertTrue(result["model_executed"])
        self.assertEqual(result["status"], "ok")
        self.assertEqual(result["result"]["feature_order_used"], self.artifact["feature_names"])
        self.assertEqual(result["result"]["predicted_condition"], "normal")

        partial = dict(features); partial.pop(self.artifact["feature_names"][0])
        blocked = SIMULATION.infer_sofi_observation({"source": "recorded_sofi", "sofi_features": partial}, artifact=self.artifact)
        self.assertFalse(blocked["model_executed"])
        self.assertEqual(blocked["status"], "not_supported")
        self.assertIn("Missing required SOFI feature", blocked["reason"])

    def test_simulation_provenance_cannot_be_overridden_by_attached_sofi_vector(self):
        features = self.Xtest.iloc[0].to_dict()
        result = SIMULATION.infer_sofi_observation({"source": "simulated topology", "sofi_features": features}, artifact=self.artifact)
        self.assertFalse(result["model_executed"])
        self.assertEqual(result["status"], "not_supported")

    def test_recovery_waits_when_followup_has_no_successful_probes(self):
        sim = REPLAY_APP.TopologySimulation()
        sim.start("2026-10-25T10:00:00+05:30")
        sim.inject("link_down", "2026-10-25T10:00:01+05:30")
        sim.pause()
        sim.clear_fault("2026-10-25T10:00:02+05:30")
        sim._observation = lambda: {"probes_sent": 4, "probes_ok": 0, "probes_failed": 4, "latency_ms": None, "packet_loss_pct": 100.0, "link_available": True, "server_reachable": True}
        _, result = sim.check("2026-10-25T10:00:03+05:30")
        self.assertEqual(result["condition"], "unknown")
        self.assertTrue(sim.recovery_pending)
        self.assertTrue(sim.active_fault)
        self.assertNotIn("Recovery detected", [event["event"] for event in sim.events])
        sim._observation = lambda: {"probes_sent": 4, "probes_ok": 4, "probes_failed": 0, "latency_ms": 8.4, "packet_loss_pct": 0.0, "link_available": True, "server_reachable": True}
        _, result = sim.check("2026-10-25T10:00:04+05:30")
        self.assertEqual(result["condition"], "normal")
        self.assertFalse(sim.recovery_pending)
        self.assertFalse(sim.active_fault)
        self.assertEqual(sim.events[-1]["event"], "Recovery detected")

    def test_recovery_is_not_reported_until_successful_followup_check(self):
        sim = REPLAY_APP.TopologySimulation()
        sim.start("2026-10-25T10:00:00+05:30")
        sim.inject("server_unreachable", "2026-10-25T10:00:01+05:30")
        sim.clear_fault("2026-10-25T10:00:02+05:30")
        self.assertFalse(sim.recovery_pending)
        self.assertEqual(sim.events[-1]["event"], "Recovery detected")
        self.assertIn("4/4 probes", sim.events[-1]["detail"])

if __name__ == "__main__":
    unittest.main(verbosity=2)
