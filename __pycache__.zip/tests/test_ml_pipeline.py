"""Controlled software tests. Generated rows here are fixtures, never training claims."""
import tempfile, unittest
from pathlib import Path
import numpy as np, pandas as pd
from ml.data_preprocessing import DatasetError, load_sofi, make_splits
from ml.train import Config, train_experiment, rule_predictions
from ml.predict import predict_network_fault, predict_record, predict_live_measurement, InferenceInputError

class MLPipelineTests(unittest.TestCase):
 def fixture(self,n_groups=80,rows_per_group=5):
  rows=[]
  for g in range(n_groups):
   for j in range(rows_per_group):
    fault=(g%8==0 and j<2)
    rows.append({'timestamp':1700000000+g*10800+j*120,'P_Bits_received':12000+g*17+(9000 if fault else 0)+j*10,'IN_Bits_sent':8400+g*31+(11000 if fault else 0),'ICMP_loss':88 if fault else 0,'ICMP_ping':0 if fault else 1,'SNMP_availability':1,'P_Interface_type':'ethernet','class':'F' if fault else 'NE'})
  return pd.DataFrame(rows)
 def test_loader_maps_labels_deduplicates_and_reports_schema(self):
  with tempfile.TemporaryDirectory() as td:
   df=self.fixture(n_groups=28,rows_per_group=5);df=pd.concat([df,df.iloc[[0]]],ignore_index=True);df.to_csv(Path(td)/'SOFI CoreSwitch-I.csv',index=False)
   second=self.fixture(n_groups=28,rows_per_group=5).rename(columns={'timestamp':'Timestamp','ICMP_loss':'icmp_LOSS','ICMP_ping':'icmp_ping','SNMP_availability':'SnMp_AvAiLaBiLiTy'});second.to_csv(Path(td)/'SOFI CoreSwitch-II.csv',index=False)
   X,y,meta,info=load_sofi(td)
   self.assertEqual(set(y.unique()),{0,1});self.assertNotIn('timestamp',X.columns);self.assertIn('icmp_loss',X.columns);self.assertIn('snmp_availability',X.columns)
   self.assertEqual(info['exact_duplicate_rows_removed'],1);self.assertEqual(info['rows_after_exact_deduplication'],len(X));self.assertGreaterEqual(info['feature_count'],5)
   self.assertEqual(len(meta['groups']),len(X))
 def test_empty_or_intrusion_label_data_rejected(self):
  with tempfile.TemporaryDirectory() as td:
   with self.assertRaises(DatasetError):load_sofi(td)
   pd.DataFrame({'timestamp':[1,2],'metric':[0,1],'class':['BENIGN','ATTACK']}).to_csv(Path(td)/'intrusion.csv',index=False)
   with self.assertRaises(DatasetError):load_sofi(td)
 def test_time_block_split_has_no_shared_groups(self):
  df=self.fixture();X=df.drop(columns=['timestamp','class']);y=(df['class']=='F').astype(int);groups=(df['timestamp']//10800)
  tr,va,te,seed=make_splits(X,y,groups)
  self.assertFalse(set(groups.iloc[tr])&set(groups.iloc[va]));self.assertFalse(set(groups.iloc[tr])&set(groups.iloc[te]));self.assertFalse(set(groups.iloc[va])&set(groups.iloc[te]))
  for ix in (tr,va,te):self.assertEqual(set(y.iloc[ix]),{0,1})
 def test_train_evaluate_serialize_and_infer(self):
  with tempfile.TemporaryDirectory() as td:
   df=self.fixture();X=df.drop(columns=['timestamp','class']);y=(df['class']=='F').astype(int);groups=df['timestamp']//10800
   artifact=Path(td)/'model.joblib';reports=Path(td)/'report'
   report=train_experiment(X,y,groups,{'dataset':'controlled test fixture','class_counts':{'NE':int((y==0).sum()),'F':int(y.sum())}},Config(seed=42,random_forest_trees=30,hgb_iterations=30,candidate_thresholds=21),reports,artifact)
   self.assertTrue(artifact.exists());self.assertTrue((reports/'confusion_matrix.png').exists());self.assertIn(report['experiment']['selected_operating_strategy'],{'supervised','isolation_forest','rules','hybrid_union'})
   record=X.iloc[-1].to_dict();first=predict_record(record,artifact_path=artifact);second=predict_record(record,artifact_path=artifact)
   normal = predict_network_fault(record, artifact_path=artifact)
   self.assertEqual(normal['status'], 'ok')
   self.assertEqual(normal['feature_order_used'], list(X.columns))
   self.assertIn('supervised_classifier', normal['components'])
   self.assertIn('isolation_forest', normal['components'])
   self.assertIn('diagnostic_rules', normal['components'])
   known_fault = X.loc[y == 1].iloc[0].to_dict()
   fault_result = predict_network_fault(known_fault, artifact_path=artifact)
   self.assertIn(fault_result['predicted_condition'], {'normal', 'fault'})
   self.assertTrue(fault_result['components']['diagnostic_rules']['evidence'] is not None)
   anomaly = X.loc[y == 0].iloc[0].to_dict()
   for feature in X.select_dtypes(include=['number', 'bool']).columns:
    anomaly[feature] = 1e15
   anomaly_result = predict_network_fault(anomaly, artifact_path=artifact)
   self.assertTrue(anomaly_result['components']['isolation_forest']['flag'])
   with self.assertRaises(InferenceInputError): predict_network_fault({'icmp_ping': 1}, artifact_path=artifact)
   bad = record.copy(); bad['ICMP_loss'] = float('inf')
   with self.assertRaises(InferenceInputError): predict_network_fault(bad, artifact_path=artifact)
   unknown = record.copy(); unknown['invented_metric'] = 1
   with self.assertRaises(InferenceInputError): predict_network_fault(unknown, artifact_path=artifact)
   self.assertEqual(first['predicted_condition'],second['predicted_condition']);self.assertIn('anomaly_score',first);self.assertIn('important_features_context',first)
   with self.assertRaises(InferenceInputError):predict_record({'ICMP_ping':1},artifact_path=artifact)
   live=predict_live_measurement({'reachable':True,'latency_ms':4.2,'service_ok':True},artifact_path=artifact)
   self.assertEqual(live['status'],'not_supported')
   self.assertTrue((reports/'evaluation.json').exists());self.assertTrue((reports/'precision_recall_curve.png').exists())
 def test_rule_evidence_is_symptomatic(self):
  X=pd.DataFrame([{'ICMP_ping':0,'ICMP_loss':95},{'ICMP_ping':1,'ICMP_loss':0}]);pred,evidence=rule_predictions(X)
  self.assertEqual(pred.tolist(),[1,0]);self.assertIn('ICMP ping reports the device unreachable',evidence[0][0])

if __name__=='__main__':unittest.main(verbosity=2)
